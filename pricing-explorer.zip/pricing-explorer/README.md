# AI Pricing and Business Model Explorer (Capstone 29)

Flask + HTML/CSS/JS + Chart.js web app for pricing, break-even and scenario analysis.
Business idea used: **handmade soy candles** (simple unit costs, many visible competitors).
All numbers shown by default are **sample data** and must be replaced with your own.

## Folder structure
```
pricing-explorer/
  app.py            Flask routes (analyse, AI, CSV export, prompts)
  calc.py           All formulas (tested independently)
  requirements.txt  Procfile  .env.example
  templates/index.html
  static/css/style.css   static/js/app.js
  data/prompts.json
  tests/test_calc.py
  docs/DOCUMENTATION.md  (report, verification log, Sheets, demo script, deployment)
```

## Run locally (Windows PowerShell / Mac / Linux)
```
cd pricing-explorer
python -m venv venv
venv\Scripts\activate            # Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python tests/test_calc.py        # expect: Ran 6 tests ... OK
python app.py
```
Open http://127.0.0.1:5000 in your browser.

## Open on your phone
1. Phone and computer on the same Wi-Fi.
2. Find your computer's IP (`ipconfig` on Windows, `ifconfig`/`ip a` on Mac/Linux), e.g. 192.168.1.20.
3. On the phone open `http://192.168.1.20:5000`. If blocked, allow Python through the firewall.

## Optional AI (Claude)
Set `ANTHROPIC_API_KEY` in your terminal before `python app.py`
(Windows: `$env:ANTHROPIC_API_KEY="your-key"`; Mac/Linux: `export ANTHROPIC_API_KEY=your-key`).
Without a key the app says no AI was called and shows only the rule-based result.
Check Anthropic's current docs for model names and API access/free limits.

## Common errors
- `'python' is not recognized`: reinstall Python and tick "Add to PATH".
- `No module named flask`: activate the venv, then `pip install -r requirements.txt`.
- Charts blank: Chart.js loads from a CDN, so you need internet.
- Port 5000 busy: change `port=5000` in `app.py`.
