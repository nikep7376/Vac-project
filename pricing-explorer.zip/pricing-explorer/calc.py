"""All financial calculations live here so they can be tested independently.

Formulas
  contribution per unit = price - variable cost
  break-even units      = ceil(fixed costs / contribution per unit)
  revenue               = price * units
  total cost            = fixed + variable * units
  profit                = revenue - total cost
  margin %              = profit / revenue * 100
  cost-plus price       = (variable + fixed / units) * (1 + markup/100)
  competitor price      = median(competitor prices) * (1 + positioning/100)
  value-based price     = perceived value * share captured / 100
"""
import math
import statistics


def num(d, key, label, minimum=0.0):
    """Read a finite number >= minimum from dict d, or raise ValueError."""
    try:
        x = float(d.get(key))
    except (TypeError, ValueError):
        raise ValueError(f"{label} must be a number.")
    if math.isnan(x) or math.isinf(x):
        raise ValueError(f"{label} must be a finite number.")
    if x < minimum:
        raise ValueError(f"{label} cannot be less than {minimum:g}.")
    return x


def breakeven(fixed, variable, price, units):
    contribution = price - variable
    revenue = price * units
    total_cost = fixed + variable * units
    profit = revenue - total_cost
    out = {
        "fixed": fixed, "variable": variable, "price": price, "units": units,
        "contribution": contribution,
        "revenue": revenue, "total_cost": total_cost, "profit": profit,
        "margin_pct": (profit / revenue * 100) if revenue > 0 else 0.0,
        "feasible": contribution > 0,
        "breakeven_units": None, "breakeven_revenue": None, "warning": None,
    }
    if contribution > 0:
        be = math.ceil(round(fixed / contribution, 9))
        out["breakeven_units"] = be
        out["breakeven_revenue"] = be * price
        out["margin_of_safety_pct"] = ((units - be) / units * 100) if units > 0 else 0.0
    else:
        out["warning"] = ("Selling price does not exceed variable cost, so every sale "
                          "loses money and break-even is impossible.")
    top = max(units, (out["breakeven_units"] or 0) * 1.5, 10)
    step = top / 10
    out["curve"] = [{"units": round(i * step, 2),
                     "revenue": price * i * step,
                     "total_cost": fixed + variable * i * step} for i in range(11)]
    return out


MODEL_INFO = {
    "cost_plus": {
        "title": "Cost-plus pricing",
        "how": "Work out the full cost of one unit, then add a markup percentage.",
        "formula": "(variable + fixed / units) x (1 + markup%)",
        "pros": "Simple; guarantees cost is covered if volume is reached.",
        "cons": "Ignores customers and competitors; wrong volume estimate gives a wrong price.",
        "use": "New products with no market data, custom/service work."},
    "competitor": {
        "title": "Competitor-based pricing",
        "how": "Position your price against what similar sellers charge.",
        "formula": "median(competitor prices) x (1 + positioning%)",
        "pros": "Reflects the real market; easy to explain.",
        "cons": "Competitors may be wrong or have different costs; data goes stale.",
        "use": "Crowded markets with similar products."},
    "value": {
        "title": "Value-based pricing",
        "how": "Price by what the product is worth to the customer, capturing part of it.",
        "formula": "perceived value x share captured%",
        "pros": "Can earn the highest margin; rewards quality and uniqueness.",
        "cons": "Perceived value is an estimate and needs customer evidence (surveys, tests).",
        "use": "Differentiated, premium or handmade products."},
}


def pricing_models(fixed, variable, units, markup, positioning, value, capture, comp_prices):
    out = {}
    if units > 0:
        unit_cost = variable + fixed / units
        out["cost_plus"] = {"price": round(unit_cost * (1 + markup / 100), 2),
                            "detail": f"Full unit cost {unit_cost:.2f} + {markup:g}% markup"}
    else:
        out["cost_plus"] = {"price": None, "detail": "Needs expected units above 0."}
    if comp_prices:
        med = statistics.median(comp_prices)
        out["competitor"] = {
            "price": round(med * (1 + positioning / 100), 2),
            "detail": f"Median {med:.2f} of {len(comp_prices)} competitor(s), positioned {positioning:+g}%",
            "min": min(comp_prices), "max": max(comp_prices),
            "average": round(statistics.mean(comp_prices), 2), "median": med}
    else:
        out["competitor"] = {"price": None, "detail": "Add at least one competitor price."}
    if value > 0:
        out["value"] = {"price": round(value * capture / 100, 2),
                        "detail": f"{capture:g}% of perceived value {value:.2f}"}
    else:
        out["value"] = {"price": None, "detail": "Enter a perceived customer value."}
    for k, v in out.items():
        v.update(MODEL_INFO[k])
    return out


def recommend(base, models, scenarios):
    """Rule-based recommendation. This is calculation + fixed rules, NOT AI."""
    prices = [m["price"] for m in models.values() if m["price"] is not None]
    floor = (base["variable"] + base["fixed"] / base["units"]) if base["units"] > 0 else None
    reasons, risks = [], []
    if not prices:
        return {"source": "rule-based", "price": None,
                "reasoning": ["Not enough data to recommend a price."],
                "risks": [], "assumptions": [], "limitations": []}
    price = statistics.median(prices)
    reasons.append(f"Median of the {len(prices)} available model price(s) is {price:.2f}.")
    if floor is not None and price < floor:
        price = floor
        reasons.append(f"Raised to {floor:.2f}, the zero-profit price at expected volume.")
    v = models["value"]["price"]
    if v is not None and floor is not None and v < floor:
        risks.append("Customers' perceived value is below your full unit cost: "
                     "the business may not be viable at this volume.")
    price = round(price, 2)
    be = breakeven(base["fixed"], base["variable"], price, base["units"])
    if be["feasible"]:
        reasons.append(f"At {price:.2f}, break-even is {be['breakeven_units']} units "
                       f"versus {base['units']:g} expected.")
        if be["breakeven_units"] > base["units"]:
            risks.append("Expected sales are below break-even: you would make a loss.")
    comp = models["competitor"]
    if comp["price"] is not None and price > comp["max"]:
        risks.append("Recommended price is above every competitor: you must justify it.")
    if comp["price"] is not None and price < comp["min"]:
        risks.append("Recommended price is below every competitor: check you are not underpricing.")
    worst = next((s for s in scenarios if s["name"] == "worst"), None)
    if worst and worst["profit"] < 0:
        risks.append(f"Worst case loses {abs(worst['profit']):.2f}. Keep a cash buffer.")
    if not be["feasible"]:
        risks.append(be["warning"])
    return {
        "source": "rule-based", "price": price, "reasoning": reasons, "risks": risks,
        "assumptions": ["Expected units, costs and perceived value entered by the user are accurate.",
                        "Competitor prices were verified on the dates shown.",
                        "Costs stay constant at every volume."],
        "limitations": ["Ignores seasonality, taxes, fees, discounts and demand changes with price.",
                        "A median rule is a starting point, not a forecast."]}


def analyse(state):
    c = state.get("costs", {})
    fixed = num(c, "fixed", "Fixed costs")
    variable = num(c, "variable", "Variable cost per unit")
    units = num(c, "units", "Expected units")
    price = num(c, "price", "Selling price")
    markup = num(c, "markup", "Markup %")
    positioning = num(c, "positioning", "Positioning %", minimum=-100)
    value = num(c, "value", "Perceived value")
    capture = num(c, "capture", "Share of value captured %")
    if capture > 100:
        raise ValueError("Share of value captured cannot exceed 100.")
    comp_prices = []
    for comp in state.get("competitors", []):
        p = num(comp, "price", f"Competitor price ({comp.get('name', '?')})")
        comp_prices.append(p)
    base = {"fixed": fixed, "variable": variable, "units": units}
    be = breakeven(fixed, variable, price, units)
    models = pricing_models(fixed, variable, units, markup, positioning, value, capture, comp_prices)
    scenarios = []
    for name in ("best", "expected", "worst"):
        s = state.get("scenarios", {}).get(name, {})
        sf = num(s, "fixed", f"{name} fixed costs")
        sv = num(s, "variable", f"{name} variable cost")
        sp = num(s, "price", f"{name} price")
        su = num(s, "units", f"{name} units")
        r = breakeven(sf, sv, sp, su)
        r.pop("curve")
        r["name"] = name
        scenarios.append(r)
    return {"breakeven": be, "models": models, "scenarios": scenarios,
            "recommendation": recommend(base, models, scenarios)}
