import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import calc


class TestCalc(unittest.TestCase):
    def test_breakeven_hand_calculated(self):
        # Worked by hand: contribution 15-5=10; BE=1000/10=100; revenue 3000;
        # total cost 1000+5*200=2000; profit 1000; margin 33.33%
        r = calc.breakeven(1000, 5, 15, 200)
        self.assertEqual(r["contribution"], 10)
        self.assertEqual(r["breakeven_units"], 100)
        self.assertEqual(r["revenue"], 3000)
        self.assertEqual(r["total_cost"], 2000)
        self.assertEqual(r["profit"], 1000)
        self.assertAlmostEqual(r["margin_pct"], 33.3333, places=3)

    def test_breakeven_rounds_up(self):
        self.assertEqual(calc.breakeven(1000, 5, 13, 0)["breakeven_units"], 125)  # 1000/8
        self.assertEqual(calc.breakeven(1000, 5, 12, 0)["breakeven_units"], 143)  # 142.86

    def test_price_not_above_variable(self):
        r = calc.breakeven(1000, 10, 10, 50)
        self.assertFalse(r["feasible"])
        self.assertIsNone(r["breakeven_units"])
        self.assertTrue(r["warning"])

    def test_cost_plus(self):
        # unit cost 5+1000/200=10; +30% = 13
        m = calc.pricing_models(1000, 5, 200, 30, 0, 0, 0, [])
        self.assertEqual(m["cost_plus"]["price"], 13.0)

    def test_competitor_and_value(self):
        m = calc.pricing_models(0, 0, 10, 0, 10, 100, 70, [10, 20, 30])
        self.assertEqual(m["competitor"]["price"], 22.0)   # median 20 * 1.10
        self.assertEqual(m["value"]["price"], 70.0)

    def test_invalid_input(self):
        with self.assertRaises(ValueError):
            calc.num({"x": "abc"}, "x", "X")
        with self.assertRaises(ValueError):
            calc.num({"x": -1}, "x", "X")


if __name__ == "__main__":
    unittest.main()
