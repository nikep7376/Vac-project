import csv
import io
import json
import os
import urllib.request
from datetime import date

from flask import Flask, Response, jsonify, render_template, request

import calc

app = Flask(__name__)
BASE = os.path.dirname(os.path.abspath(__file__))


@app.route("/")
def index():
    return render_template("index.html")


@app.post("/api/analyse")
def api_analyse():
    try:
        return jsonify(calc.analyse(request.get_json(silent=True) or {}))
    except ValueError as e:
        return jsonify(error=str(e)), 400


@app.get("/api/prompts")
def api_prompts():
    with open(os.path.join(BASE, "data", "prompts.json"), encoding="utf-8") as f:
        return jsonify(json.load(f))


@app.post("/api/ai")
def api_ai():
    """Calls Claude only if ANTHROPIC_API_KEY is set. Never fakes a response."""
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key:
        return jsonify(source="unavailable",
                       message="No AI API key configured. Showing the rule-based "
                               "recommendation only. No AI was called.")
    state = request.get_json(silent=True) or {}
    try:
        result = calc.analyse(state)
    except ValueError as e:
        return jsonify(error=str(e)), 400
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")
    prompt = ("You are a pricing advisor for a small business. Using ONLY the data "
              "below, recommend a selling price. Explain reasoning, risks, assumptions "
              "and limitations. Do not invent competitor prices or market data. "
              "Under 250 words.\n\nBusiness: " + json.dumps(state.get("idea", {})) +
              "\nCompetitors (user-entered): " + json.dumps(state.get("competitors", [])) +
              "\nCalculated results: " + json.dumps({
                  "models": {k: v["price"] for k, v in result["models"].items()},
                  "breakeven_units": result["breakeven"]["breakeven_units"],
                  "scenarios": [{k: s[k] for k in ("name", "revenue", "profit")}
                                for s in result["scenarios"]]}))
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": model, "max_tokens": 700,
                         "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"content-type": "application/json", "x-api-key": key,
                 "anthropic-version": "2023-06-01"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            data = json.load(r)
        text = "".join(b.get("text", "") for b in data.get("content", []))
        return jsonify(source="ai", model=model, text=text)
    except Exception as e:  # network, auth, quota...
        return jsonify(source="error", message=f"AI call failed: {e}"), 502


@app.post("/api/export.csv")
def api_export():
    state = request.get_json(silent=True) or {}
    try:
        r = calc.analyse(state)
    except ValueError as e:
        return jsonify(error=str(e)), 400
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["AI Pricing and Business Model Explorer export", date.today().isoformat()])
    w.writerow(["Business", state.get("idea", {}).get("name", "")])
    w.writerow([])
    w.writerow(["Break-even (calculated)"])
    b = r["breakeven"]
    for k in ("fixed", "variable", "price", "units", "contribution", "breakeven_units",
              "revenue", "total_cost", "profit", "margin_pct"):
        w.writerow([k, b[k]])
    w.writerow([])
    w.writerow(["Pricing models (calculated)", "price", "detail"])
    for k, m in r["models"].items():
        w.writerow([m["title"], m["price"], m["detail"]])
    w.writerow([])
    w.writerow(["Scenario", "price", "units", "variable", "fixed", "revenue", "total_cost", "profit"])
    for s in r["scenarios"]:
        w.writerow([s["name"], s["price"], s["units"], s["variable"], s["fixed"],
                    s["revenue"], s["total_cost"], s["profit"]])
    w.writerow([])
    w.writerow(["Competitors (user-entered; verify at source)", "price", "url", "date checked"])
    for c in state.get("competitors", []):
        w.writerow([c.get("name"), c.get("price"), c.get("url"), c.get("checked")])
    w.writerow([])
    rec = r["recommendation"]
    w.writerow(["Rule-based recommendation (not AI)", rec["price"]])
    for line in rec["reasoning"] + rec["risks"]:
        w.writerow(["", line])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=pricing_analysis.csv"})


if __name__ == "__main__":
    # host 0.0.0.0 lets your phone (same Wi-Fi) open http://<PC-IP>:5000
    app.run(host="0.0.0.0", port=5000, debug=True)
