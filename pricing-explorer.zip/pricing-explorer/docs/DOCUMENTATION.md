# Capstone 29 - Documentation

## Abstract
A web application that helps a small venture compare cost-plus, competitor-based and value-based prices, compute break-even, test best/expected/worst scenarios, and receive a rule-based and optional AI-assisted recommendation. Calculations are done in tested Python code; AI text is labelled as a suggestion.

## Objectives
Answer: "Can AI help evaluate pricing options and simple business models for a small venture?" by building, verifying and demonstrating the tool.

## Methodology
1. Choose a business (handmade candles). 2. Gather costs and competitor prices manually from official pages (with URL and date). 3. Compute three pricing models. 4. Compute break-even and scenarios. 5. Verify with unit tests, Google Sheets and a second tool. 6. Compare AI suggestion with rule-based result. 7. Record errors and corrections.

## Modules
Idea/costs, competitors, pricing models, break-even, scenarios, recommendations (rule-based + optional AI), summary/report, CSV export, prompt library.

## Formulas
- Contribution = price - variable cost
- Break-even units = ceil(fixed / contribution)
- Revenue = price x units; Total cost = fixed + variable x units; Profit = revenue - total cost
- Cost-plus = (variable + fixed/units) x (1 + markup%)
- Competitor = median(prices) x (1 + positioning%)
- Value-based = perceived value x share captured%

## Google Sheets break-even sheet (build this yourself)
Sheet "BreakEven", labels in A, values in B:
| Cell | Content |
|---|---|
| A1/B1 | Fixed costs / 500 |
| A2/B2 | Variable cost per unit / 6 |
| A3/B3 | Selling price / 14 |
| A4/B4 | Expected units / 150 |
| A5/B5 | Contribution per unit: `=B3-B2` |
| A6/B6 | Break-even units: `=IF(B5>0,ROUNDUP(B1/B5,0),"Impossible")` |
| A7/B7 | Revenue: `=B3*B4` |
| A8/B8 | Total cost: `=B1+B2*B4` |
| A9/B9 | Profit: `=B7-B8` |
| A10/B10 | Margin %: `=IF(B7>0,B9/B7,0)` (format as %) |
Chart data: column D units 0,10,20..., E `=$B$3*D2`, F `=$B$1+$B$2*D2`; insert a line chart of E:F.
Scenarios: copy columns B for Best, Expected, Worst (C, D, E) and change inputs.
Expected check with the sample inputs: contribution 8, break-even 63, revenue 2100, total cost 1400, profit 700.

## Verification log (fill in as you test)
Hand check done while building (sample inputs 500 / 6 / 14 / 150): contribution 8; break-even 62.5 -> 63; revenue 2100; total cost 1400; profit 700; cost-plus price 13.07. Unit tests cover these and edge cases.
| Date | Item checked | App result | Independent result (Sheets/ChatGPT/hand) | Match? | Correction |
|---|---|---|---|---|---|
| | | | | | |

Incorrect/outdated information log: record each AI or source error, where you found it, and the correction.

## Responsible AI
- Privacy: only business numbers collected; stored in your browser (localStorage), not in a database.
- Copyright: link to competitor pages, do not copy their content or images.
- Transparency: AI output is labelled; if no key, no AI is called.
- Limits: ignores taxes, fees, seasonality, and price-demand effects; competitor prices go stale; AI can be wrong.

## AI tools (check current free-tier limits yourself; they change)
Claude (planning/coding/analysis), ChatGPT (verification, prompts), Gemini or Perplexity (competitor source discovery; open every link), Google Sheets (formulas), Canva or Gamma (presentation).

## Automation / workflow demonstration
Show: enter data -> auto-recalculation (300 ms after typing) -> export CSV -> open in Sheets -> compare.

## Before-and-after analysis
Before: guess price 10 with no analysis. After: record both prices with profit, break-even and worst case from the app. Use your real numbers; do not reuse sample values as results.

## Demo script (5-7 min)
1. State the question. 2. Show idea and costs. 3. Add 2-3 real competitors with URLs and dates. 4. Show three models. 5. Break-even chart. 6. Scenarios. 7. Rule-based vs AI (or "no key, no AI called"). 8. Export CSV and print report. 9. Show unit tests passing and Sheets match. 10. Limitations and conclusion.

## Results / Conclusion (write after your own testing)
Describe measured outcomes from your real data. Suggested conclusion: AI can speed up research and explanation, but pricing decisions need verified data and independent calculation.

## Deployment (free options; confirm current limits before relying on them)
PythonAnywhere (Flask-friendly) or Render (uses `Procfile`/gunicorn). Set `ANTHROPIC_API_KEY` as an environment variable on the host, never in code.
