"use strict";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money = (n) => n === null || n === undefined ? "n/a" : Number(n).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
const cls = (n) => n >= 0 ? "pos" : "neg";
const NAMES = ["best", "expected", "worst"];
const FIELDS = ["price", "units", "variable", "fixed"];
let competitors = [];
let scenarios = {};
let charts = {};
let last = null;
let timer = null;

function tryStore(op, key, val) {
  try { return op === "get" ? localStorage.getItem(key) : op === "set" ? localStorage.setItem(key, val) : localStorage.removeItem(key); } catch (e) { return null; }
}

function costs() {
  const g = (id) => $(id).value;
  return {fixed: g("fixed"), variable: g("variable"), units: g("units"), price: g("price"),
          markup: g("markup"), positioning: g("positioning"), value: g("value"), capture: g("capture")};
}
function state() {
  return {idea: {name: $("idea_name").value, description: $("idea_desc").value},
          costs: costs(), competitors, scenarios};
}

function autofill() {
  const c = costs();
  const f = (x) => Number(x) || 0;
  const r = (x) => Math.round(x * 100) / 100;
  scenarios = {
    best: {price: r(f(c.price) * 1.10), units: Math.round(f(c.units) * 1.25), variable: r(f(c.variable) * 0.95), fixed: f(c.fixed)},
    expected: {price: f(c.price), units: f(c.units), variable: f(c.variable), fixed: f(c.fixed)},
    worst: {price: r(f(c.price) * 0.90), units: Math.round(f(c.units) * 0.70), variable: r(f(c.variable) * 1.10), fixed: r(f(c.fixed) * 1.10)}
  };
  renderScenarioInputs();
}

function renderScenarioInputs() {
  let h = "<thead><tr><th></th>" + NAMES.map((n) => `<th>${n}</th>`).join("") + "</tr></thead><tbody>";
  const labels = {price: "Selling price", units: "Units sold", variable: "Variable cost / unit", fixed: "Fixed costs"};
  for (const f of FIELDS) {
    h += `<tr><td>${labels[f]}</td>` + NAMES.map((n) => `<td><input type="number" step="any" min="0" data-sc="${n}" data-f="${f}" value="${scenarios[n][f]}"></td>`).join("") + "</tr>";
  }
  h += `</tbody><tbody id="sc_results"></tbody>`;
  $("sc_table").innerHTML = h;
  document.querySelectorAll("[data-sc]").forEach((el) => el.addEventListener("input", () => {
    scenarios[el.dataset.sc][el.dataset.f] = el.value; schedule();
  }));
}

function renderCompetitors() {
  const tb = $("c_table").querySelector("tbody");
  tb.innerHTML = competitors.map((c, i) => `<tr><td>${esc(c.name)}</td><td>${money(c.price)}</td>
    <td>${c.url ? `<a href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">source</a>` : "<em>no source</em>"}</td>
    <td>${esc(c.checked) || "<em>unknown</em>"}</td><td><button class="link" data-del="${i}">remove</button></td></tr>`).join("") ||
    `<tr><td colspan="5"><em>No competitors yet.</em></td></tr>`;
  tb.querySelectorAll("[data-del]").forEach((b) => b.addEventListener("click", () => { competitors.splice(+b.dataset.del, 1); schedule(); renderCompetitors(); }));
  const p = competitors.map((c) => Number(c.price)).filter((x) => !isNaN(x));
  $("c_stats").textContent = p.length ? `Min ${money(Math.min(...p))} | Max ${money(Math.max(...p))} | Average ${money(p.reduce((a, b) => a + b, 0) / p.length)}` : "";
}

function chart(id, cfg) {
  if (charts[id]) charts[id].destroy();
  charts[id] = new Chart($(id), cfg);
}

function showError(msg) { $("error").hidden = !msg; $("error").textContent = msg || ""; }

async function analyse() {
  try {
    const res = await fetch("/api/analyse", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(state())});
    const data = await res.json();
    if (!res.ok) { showError(data.error || "Invalid input."); return; }
    showError(""); last = data; render(data);
    tryStore("set", "pricing_state", JSON.stringify(state()));
  } catch (e) { showError("Cannot reach the server. Is Flask running?"); }
}
function schedule() { clearTimeout(timer); timer = setTimeout(analyse, 300); }

function render(d) {
  // models
  $("model_cards").innerHTML = Object.values(d.models).map((m) => `<div class="card"><h3>${m.title} <span class="tag calc">calculated</span></h3>
    <div class="big">${money(m.price)}</div><p class="hint">${esc(m.detail)}</p>
    <p><b>Formula:</b> ${esc(m.formula)}</p><p><b>Pros:</b> ${m.pros}</p><p><b>Cons:</b> ${m.cons}</p><p><b>Best for:</b> ${m.use}</p></div>`).join("");
  const mv = Object.values(d.models);
  chart("chart_models", {type: "bar", data: {labels: mv.map((m) => m.title), datasets: [{label: "Suggested price", data: mv.map((m) => m.price), backgroundColor: "#2457d6"}]}, options: {plugins: {legend: {display: false}}}});
  // break-even
  const b = d.breakeven;
  $("be_out").innerHTML = (b.warning ? `<div class="warn">${esc(b.warning)}</div>` : "") + `<div class="scroll"><table>
    <tr><th>Contribution per unit</th><td>${money(b.contribution)}</td></tr>
    <tr><th>Break-even units</th><td>${b.breakeven_units ?? "impossible"}</td></tr>
    <tr><th>Break-even revenue</th><td>${money(b.breakeven_revenue)}</td></tr>
    <tr><th>Expected revenue</th><td>${money(b.revenue)}</td></tr>
    <tr><th>Total cost</th><td>${money(b.total_cost)}</td></tr>
    <tr><th>Profit</th><td class="${cls(b.profit)}">${money(b.profit)} (${b.margin_pct.toFixed(1)}% margin)</td></tr></table></div>`;
  chart("chart_be", {type: "line", data: {labels: b.curve.map((p) => p.units), datasets: [
    {label: "Revenue", data: b.curve.map((p) => p.revenue), borderColor: "#157347", tension: 0},
    {label: "Total cost", data: b.curve.map((p) => p.total_cost), borderColor: "#b42318", tension: 0}]},
    options: {scales: {x: {title: {display: true, text: "Units sold"}}}}});
  // scenarios
  $("sc_results").innerHTML = ["revenue", "total_cost", "profit"].map((k) => `<tr><th>${k.replace("_", " ")}</th>` + d.scenarios.map((s) => `<td class="${k === "profit" ? cls(s[k]) : ""}">${money(s[k])}</td>`).join("") + "</tr>").join("") +
    `<tr><th>break-even units</th>` + d.scenarios.map((s) => `<td>${s.breakeven_units ?? "impossible"}</td>`).join("") + "</tr>";
  chart("chart_sc", {type: "bar", data: {labels: d.scenarios.map((s) => s.name), datasets: [
    {label: "Revenue", data: d.scenarios.map((s) => s.revenue), backgroundColor: "#2457d6"},
    {label: "Profit", data: d.scenarios.map((s) => s.profit), backgroundColor: "#157347"}]}});
  // recommendation + summary
  const r = d.recommendation;
  const list = (a) => a.length ? "<ul>" + a.map((x) => `<li>${esc(x)}</li>`).join("") + "</ul>" : "<p class='hint'>None.</p>";
  $("rule_out").innerHTML = `<div class="big">${money(r.price)}</div><h4>Reasoning</h4>${list(r.reasoning)}<h4>Risks</h4>${list(r.risks)}<h4>Assumptions</h4>${list(r.assumptions)}<h4>Limitations</h4>${list(r.limitations)}`;
  renderSummary(d);
}

function renderSummary(d) {
  const s = state(); const b = d.breakeven; const r = d.recommendation;
  $("summary_out").innerHTML = `<h3>Business: ${esc(s.idea.name)}</h3><p>${esc(s.idea.description)}</p>
  <p class="hint">Report date: ${new Date().toLocaleDateString()}</p>
  <h3>Competitors (user-entered; verify at source)</h3>
  <table><tr><th>Name</th><th>Price</th><th>Source</th><th>Checked</th></tr>${competitors.map((c) => `<tr><td>${esc(c.name)}</td><td>${money(c.price)}</td><td>${esc(c.url)}</td><td>${esc(c.checked)}</td></tr>`).join("") || "<tr><td colspan=4>None entered</td></tr>"}</table>
  <h3>Pricing models <span class="tag calc">calculated</span></h3>
  <table><tr><th>Model</th><th>Price</th><th>Basis</th></tr>${Object.values(d.models).map((m) => `<tr><td>${m.title}</td><td>${money(m.price)}</td><td>${esc(m.detail)}</td></tr>`).join("")}</table>
  <h3>Break-even <span class="tag calc">calculated</span></h3>
  <p>Contribution ${money(b.contribution)} per unit. Break-even: <b>${b.breakeven_units ?? "impossible"}</b> units. Expected profit at ${money(b.price)} x ${b.units}: <span class="${cls(b.profit)}">${money(b.profit)}</span>.</p>
  <h3>Scenarios</h3>
  <table><tr><th>Scenario</th><th>Revenue</th><th>Total cost</th><th>Profit</th></tr>${d.scenarios.map((x) => `<tr><td>${x.name}</td><td>${money(x.revenue)}</td><td>${money(x.total_cost)}</td><td class="${cls(x.profit)}">${money(x.profit)}</td></tr>`).join("")}</table>
  <h3>Final recommendation <span class="tag calc">rule-based</span></h3>
  <p class="big">${money(r.price)}</p>${r.reasoning.map((x) => `<p>${esc(x)}</p>`).join("")}
  <h4>Risks</h4>${r.risks.map((x) => `<p>${esc(x)}</p>`).join("") || "<p>None flagged.</p>"}
  <h4>Assumptions and limitations</h4><ul>${r.assumptions.concat(r.limitations).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
  <p class="hint">Verification note: competitor prices are manual entries and must be re-checked at the source URL. AI text, if any, is a suggestion and was not used in the calculations above.</p>`;
}

async function askAI() {
  $("ai_out").textContent = "Contacting server...";
  try {
    const res = await fetch("/api/ai", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(state())});
    const d = await res.json();
    if (d.source === "ai") $("ai_out").innerHTML = `<p class="hint">Generated by ${esc(d.model)}. Treat as a suggestion.</p><div style="white-space:pre-wrap">${esc(d.text)}</div>`;
    else $("ai_out").textContent = d.message || d.error || "No AI response.";
  } catch (e) { $("ai_out").textContent = "Request failed. No AI was used."; }
}

async function exportCsv() {
  const res = await fetch("/api/export.csv", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(state())});
  if (!res.ok) { showError((await res.json()).error || "Export failed"); return; }
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement("a"); a.href = url; a.download = "pricing_analysis.csv"; a.click(); URL.revokeObjectURL(url);
}

async function loadPrompts() {
  try {
    const list = await (await fetch("/api/prompts")).json();
    $("prompt_out").innerHTML = list.map((p, i) => `<div class="card"><h3>${esc(p.title)}</h3><p><b>Why it works:</b> ${esc(p.why)}</p>
      <pre style="white-space:pre-wrap;background:#f0f3fa;padding:8px;border-radius:6px" id="pr${i}">${esc(p.prompt)}</pre>
      <button class="secondary" data-copy="${i}">Copy</button></div>`).join("");
    document.querySelectorAll("[data-copy]").forEach((b) => b.addEventListener("click", () => navigator.clipboard.writeText($("pr" + b.dataset.copy).textContent)));
  } catch (e) { $("prompt_out").textContent = "Could not load prompts."; }
}

function setSample() {
  competitors = [
    {name: "SAMPLE Competitor A", price: 12, url: "", checked: ""},
    {name: "SAMPLE Competitor B", price: 16, url: "", checked: ""},
    {name: "SAMPLE Competitor C", price: 22, url: "", checked: ""}];
  renderCompetitors(); autofill(); schedule();
}

function init() {
  ["idea_name", "idea_desc", "fixed", "variable", "units", "price", "markup", "positioning", "value", "capture"].forEach((id) => $(id).addEventListener("input", schedule));
  $("c_add").addEventListener("click", () => {
    const name = $("c_name").value.trim(), price = $("c_price").value;
    if (!name || price === "" || Number(price) < 0) { showError("Competitor name and a non-negative price are required."); return; }
    competitors.push({name, price: Number(price), url: $("c_url").value.trim(), checked: $("c_date").value});
    ["c_name", "c_price", "c_url", "c_date"].forEach((id) => $(id).value = "");
    renderCompetitors(); schedule();
  });
  $("sample").addEventListener("click", setSample);
  $("reset").addEventListener("click", () => { tryStore("del", "pricing_state"); location.reload(); });
  $("autofill").addEventListener("click", () => { autofill(); schedule(); });
  $("ai_btn").addEventListener("click", askAI);
  $("csv").addEventListener("click", exportCsv);
  $("print").addEventListener("click", () => window.print());
  const saved = tryStore("get", "pricing_state");
  if (saved) {
    try {
      const s = JSON.parse(saved);
      $("idea_name").value = s.idea.name; $("idea_desc").value = s.idea.description;
      for (const k of Object.keys(s.costs)) if ($(k)) $(k).value = s.costs[k];
      competitors = s.competitors || []; scenarios = s.scenarios || {};
    } catch (e) { /* ignore corrupt data */ }
  }
  if (!scenarios.best) autofill(); else renderScenarioInputs();
  renderCompetitors(); loadPrompts(); analyse();
}
document.addEventListener("DOMContentLoaded", init);
